<?php
return include $modx->getOption('core_path').'components/migx/model/imageupload/imageupload.php';