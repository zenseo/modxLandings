--------------------
Snippet: renderResources
--------------------
Version: 1.0.1-pl
Released: April 3, 2012
Since: March 19, 2012
Author: Jason Coward <jason@modx.com>

Render the complete output of a collection of Resources in MODX Revolution.

Official Documentation:
http://rtfm.modx.com/display/ADDON/renderResources
